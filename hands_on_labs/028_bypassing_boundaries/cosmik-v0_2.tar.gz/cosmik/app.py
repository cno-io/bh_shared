import subprocess
from flask import Flask, escape
from arox import SocksRelay
from zappa.async import task
import logging

app = Flask(__name__.split('.')[0], static_folder=None)
logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger('app.py')

@task
def run_socks(tunnel_addr):
	tunnel_addr = (tunnel_addr.split(':')[0], int(tunnel_addr.split(':')[1]))
	relay = SocksRelay(transport_addr=tunnel_addr)
	relay.run()

@app.route('/socks/<path:tunnel_addr>', methods=['GET'])
def socks_proxy(tunnel_addr):
	try:
		if len(tunnel_addr.split(':')) != 2:
			raise
	except:
		return escape('Expected host:port, got %s') % (tunnel_addr)
	run_socks(tunnel_addr)
	return escape('Executed socks task!')
