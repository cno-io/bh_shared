import nmap, boto3, os, socket, json, time, subprocess

def store_to_s3(ip, results):
    s3client = boto3.client("s3")
    bucketName = os.environ['s3bucket']
    keyname = "%s-%s" % (ip, int(time.time()))
    retval = s3client.put_object(
        Body=results,
        Bucket=bucketName,
        Key=keyname
        )
    return retval

def scan_ip(ip):
    nm = nmap.PortScanner()
    nm.scan(ip)
    return nm.csv()

def lambda_handler(event, context):
    os.environ['PATH'] += os.pathsep + "/var/task/bin"
    messages = []
    if not "Records" in event.keys():
        return None
    if len(event['Records']) > 1:
        return None
    for r in event['Records']:
        if not "Sns" in r.keys():
            return None
        else:
            messages.append(str(r['Sns']['Message']))

    target_ips = []
    for m in messages:
        try:
            socket.inet_aton(m)
            target_ips.append(m)
        except socket.error:
            print "Invalid IP address: %s" % m
            pass
    for t in target_ips:
        res = scan_ip(t)
        store_to_s3(t, res)
    return

