const {gzip} = require('zlib')
const aws = require('aws-sdk')
const s3 = new aws.S3()
const getDecompressedBody = require('./functions/getDecompressedBody')
const isCloudTrailLog = require('./functions/isCloudTrailLog')
const isCloudTrailDigest = require('./functions/isCloudTrailDigest')
const catchError = require('./functions/catchError')
const shouldHideRecord = require('./functions/shouldHideRecord')

function check(event, context) {
  if (event.hasOwnProperty('Records')) { // If we recieve the wrong kind of event we would run into issues, therefore we ensure the expected event property is there
    event.Records.forEach(record => {
      const Bucket = record.s3.bucket.name
      const Key = record.s3.object.key
      if (isCloudTrailLog(Key)) {
        s3.getObject({Bucket, Key}, catchError(object => { // Get the uploaded object
          getDecompressedBody(object, catchError(data => { // Decompress the body
            if (object.ContentType !== 'application/json') return console.error(new Error('Invalid Log Content Type')) // Ensure JSON content type
            data = JSON.parse(data.toString('utf8')) // Convert the body from a buffer to JSON
            let keepRecords = data.Records.filter(shouldHideRecord) // Filter each of the records into a new array
            //keepRecords = keepRecords.filter(record => !(record.hasOwnProperty('requestParameters') && record.requestParameters.hasOwnProperty('logGroupName') && record.requestParameters.logGroupName === context.logGroupName)) // Filter out logs created by this lambda function
            if (keepRecords.length < data.Records.length) { // We can check if the filtered records have less records (meaning we filtered out more than 0 records), and if it does we reupload the new version
              data.Records = keepRecords // Assign the new records to the old file
              let outputFile = JSON.stringify(data) // Parse the old file with the new records into a string for the new file
              gzip(new Buffer(outputFile, 'utf8'), catchError(outputBuffer => { // Compress the new file string
                s3.putObject({ // Upload the file
                  Bucket,
                  Key,
                  Body: outputBuffer,
                  ContentType: 'application/json',
                  ContentEncoding: 'gzip'
                }, catchError)
              }))
            }
          }))
        }))
      } else if (isCloudTrailDigest(Key)) {
        s3.deleteObject({Bucket, Key}, catchError) // Delete the digest
      }
    })
  }
}

exports.handler = check
