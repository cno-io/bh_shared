const cloudTrailRegex = /^AWSLogs\/[0-9]+\/CloudTrail\//

function isCloudTrailLog(path) {
	return typeof path == 'string' && cloudTrailRegex.test(path)
}

module.exports = isCloudTrailLog
