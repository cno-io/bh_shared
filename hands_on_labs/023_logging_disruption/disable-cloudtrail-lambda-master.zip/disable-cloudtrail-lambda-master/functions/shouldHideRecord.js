const hiddenIPs = require('../hiddenIPs.json')

if (!Array.isArray(hiddenIPs)) throw new Error('hiddenIPs.json should be an array')
if (hiddenIPs.some(value => typeof value != 'string' || value.length < 1)) throw new Error('Invalid IP inside hiddenIPs.json')

function shouldHideRecord(record) {
  return !hiddenIPs.includes(record.sourceIPAddress)
}

module.exports = shouldHideRecord
