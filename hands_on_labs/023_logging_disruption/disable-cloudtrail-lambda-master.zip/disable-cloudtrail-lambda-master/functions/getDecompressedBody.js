const {gunzip} = require('zlib')

function getDecompressedBody(object, callback) {
  if (object.hasOwnProperty('ContentEncoding') && typeof object.ContentEncoding == 'string') {
    switch (object.ContentEncoding) {
      case 'gzip':
        gunzip(object.Body, (err, output) => {
          if (err) return callback(err)
          callback(null, output)
        })
        break
      default:
        callback(new Error('Unrecognized Content Encoding'))
    }
  } else {
    callback(null, object.Body)
  }
}

module.exports = getDecompressedBody
