function catchError(error) {
    if (typeof error == 'function') {
        return (err, ...args) => {
            if (![null, undefined].includes(err)) {
                console.error(err) // Uncomment to log errors in CloudWatch
            } else {
                error(...args)
            }
        }
    } else if (![null, undefined].includes(error)) {
      console.error(error)
    }
}

module.exports = catchError
