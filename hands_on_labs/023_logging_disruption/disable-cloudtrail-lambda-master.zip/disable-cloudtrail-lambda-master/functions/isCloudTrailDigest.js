const cloudTrailDigestRegex = /^AWSLogs\/[0-9]+\/CloudTrail-Digest\//

function isCloudTrailDigest(path) {
	return typeof path == 'string' && cloudTrailDigestRegex.test(path)
}

module.exports = isCloudTrailDigest
