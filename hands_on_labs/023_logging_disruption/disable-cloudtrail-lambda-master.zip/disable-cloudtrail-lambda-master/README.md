# Disable Cloudtrail Lambda
A lambda function that deletes digests and filters logs automatically
## Setting Up
1. Update hiddenIPs.json with the IPs you want to hide
2. Launch the Lambda
3. Disable Log Verification
4. Enable Log Verification
